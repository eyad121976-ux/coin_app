(function () {
  'use strict';
  if (!Api.token()) { location.replace('index.html'); return; }

  const $ = s => document.querySelector(s);
  const D = {
    ar: {
      title: 'لوحة الإدارة', back: 'رجوع', tab_overview: 'نظرة عامة', tab_users: 'المستخدمون', tab_risk: 'المخاطر',
      users: 'المستخدمون', blocked: 'الموقوفون', coins_total: 'إجمالي الكوينز', ads_today: 'إعلانات اليوم', games_today: 'مباريات اليوم',
      ads_days: 'الإعلانات المعتمدة يومياً (7 أيام)', placements: 'الإعلانات المعتمدة حسب الموضع (7 أيام)', none: 'لا يوجد', ads: 'إعلان',
      search: 'بحث باسم المستخدم', block: 'إيقاف', unblock: 'تفعيل', adjust: 'تسوية كوينز', adj_amount: 'عدد الكوينز (سالب للخصم)', adj_note: 'سبب التسوية (إلزامي)',
      confirm_act: 'تأكيد التنفيذ؟', coins: 'كوينز', coins_after: 'الرصيد بعد التسوية',
      r_ip: 'حسابات تشترك في نفس الشبكة', r_noplay: 'إعلانات كثيرة بدون لعب', r_max: 'يبلغون الحد اليومي باستمرار', r_new: 'حسابات جديدة بإعلانات كثيرة',
      r_log: 'آخر إجراءات الإدارة', accounts: 'حسابات', days_n: 'أيام', risk_note: 'هذه مؤشرات اشتباه للمراجعة فقط ولا توقف أحداً تلقائياً.'
    },
    en: {
      title: 'Admin panel', back: 'Back', tab_overview: 'Overview', tab_users: 'Users', tab_risk: 'Risk',
      users: 'Users', blocked: 'Blocked', coins_total: 'Total coins', ads_today: 'Ads today', games_today: 'Games today',
      ads_days: 'Verified ads per day (7 days)', placements: 'Verified ads by placement (7 days)', none: 'None', ads: 'ads',
      search: 'Search by username', block: 'Block', unblock: 'Unblock', adjust: 'Adjust coins', adj_amount: 'Coins (negative to deduct)', adj_note: 'Reason (required)',
      confirm_act: 'Confirm this action?', coins: 'coins', coins_after: 'Balance after adjustment',
      r_ip: 'Accounts sharing a network', r_noplay: 'Many ads but no gameplay', r_max: 'Constantly hitting the daily limit', r_new: 'New accounts with many ads',
      r_log: 'Recent admin actions', accounts: 'accounts', days_n: 'days', risk_note: 'These are suspicion signals for review only; nobody is blocked automatically.'
    }
  };
  const T = k => (D[I18n.lang()] || D.ar)[k] || k;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const body = $('#a-body');
  let tab = 'overview';

  function msg(text, type) {
    const m = $('#a-msg');
    if (!text) { m.className = 'alert d-none'; return; }
    m.className = 'alert alert-' + (type || 'danger'); m.textContent = text;
  }
  async function call(route, method, data) {
    const r = await Api.call(route, method, data);
    if (!r.ok) {
      if (r.error === 'err_unauth' || r.error === 'err_admin') { if (r.error === 'err_unauth') Api.setToken(null); location.replace('index.html'); return r; }
      msg((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : ''));
    }
    return r;
  }

  function tabs() {
    const list = [['overview', 'tab_overview'], ['users', 'tab_users'], ['risk', 'tab_risk']];
    $('#a-tabs').innerHTML = list.map(([id, k]) =>
      '<li class="nav-item"><button type="button" class="nav-link' + (tab === id ? ' active' : '') + '" data-tab="' + id + '">' + T(k) + '</button></li>').join('');
    $('#a-tabs').querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => { tab = b.dataset.tab; msg(''); render(); }));
    $('#a-title').textContent = T('title'); $('#a-back').textContent = T('back');
  }

  async function viewOverview() {
    const r = await call('admin/overview'); if (!r.ok) return;
    const kv = (k, v) => '<div class="col-6 col-md-4"><div class="card-s kv">' + T(k) + '<b>' + v + '</b></div></div>';
    const days = r.ads_days.length ? r.ads_days.map(d => '<div class="kv">' + esc(d.day) + ' · <b style="display:inline;font-size:1rem">' + d.n + '</b> ' + T('ads') + '</div>').join('') : '<div class="kv">' + T('none') + '</div>';
    const pl = r.placements.length ? r.placements.map(p => '<span class="badge text-bg-secondary me-1">' + esc(p.placement) + ': ' + p.n + '</span>').join('') : '<div class="kv">' + T('none') + '</div>';
    body.innerHTML = '<div class="row g-2 mb-3">' + kv('users', r.users) + kv('blocked', r.blocked) + kv('coins_total', '🪙 ' + r.coins_total) + kv('ads_today', r.ads_today) + kv('games_today', r.games_today) + '</div>' +
      '<h2 class="h6 text-warning">' + T('ads_days') + '</h2>' + days + '<h2 class="h6 text-warning mt-3">' + T('placements') + '</h2>' + pl;
  }

  async function viewUsers(q) {
    const r = await call('admin/users', 'POST', { q: q || '' }); if (!r.ok) return;
    const rows = r.items.length ? r.items.map(u =>
      '<div class="card-s mb-2"><div class="d-flex justify-content-between"><b>' + esc(u.username) + '</b><span class="badge text-bg-' + (u.status === 'active' ? 'success' : 'danger') + '">' + esc(u.status) + '</span></div>' +
      '<div class="kv">#' + u.id + ' · ' + esc(u.email || '—') + ' · 🪙 ' + u.coins + ' · ' + T('ads_today') + ': ' + u.ads_today + '</div>' +
      '<div class="d-flex gap-2 mt-2"><button type="button" class="btn btn-sm btn-outline-' + (u.status === 'active' ? 'danger' : 'success') + '" data-st="' + (u.status === 'active' ? 'blocked' : 'active') + '" data-id="' + u.id + '">' + (u.status === 'active' ? T('block') : T('unblock')) + '</button>' +
      '<button type="button" class="btn btn-sm btn-outline-warning" data-adj="' + u.id + '">' + T('adjust') + '</button></div></div>').join('') : '<div class="kv">' + T('none') + '</div>';
    body.innerHTML = '<input id="u-q" class="form-control mb-3" placeholder="' + esc(T('search')) + '" value="' + esc(q || '') + '" dir="ltr">' + rows;
    $('#u-q').addEventListener('keydown', e => { if (e.key === 'Enter') viewUsers(e.target.value.trim()); });
    body.querySelectorAll('[data-st]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm(T('confirm_act'))) return;
      const rr = await call('admin/user_status', 'POST', { id: parseInt(b.dataset.id, 10), status: b.dataset.st });
      if (rr.ok) viewUsers($('#u-q').value.trim());
    }));
    body.querySelectorAll('[data-adj]').forEach(b => b.addEventListener('click', async () => {
      const amount = prompt(T('adj_amount'), ''); if (!amount) return;
      const note = prompt(T('adj_note'), ''); if (!note) return;
      const rr = await call('admin/adjust', 'POST', { user_id: parseInt(b.dataset.adj, 10), amount: amount.trim(), note: note.trim() });
      if (rr.ok) { msg(T('coins_after') + ': 🪙 ' + rr.coins, 'success'); viewUsers($('#u-q').value.trim()); }
    }));
  }

  async function viewRisk() {
    const r = await call('admin/risk'); if (!r.ok) return;
    const list = (title, rows, fmt) => '<h2 class="h6 text-warning mt-3">' + T(title) + '</h2>' +
      (rows.length ? rows.map(x => '<div class="card-s mb-1 kv">' + fmt(x) + '</div>').join('') : '<div class="kv">' + T('none') + '</div>');
    body.innerHTML = '<div class="kv mb-2">' + T('risk_note') + '</div>' +
      list('r_ip', r.ip_clusters, x => '<b>' + x.accounts + ' ' + T('accounts') + '</b> · ' + esc(x.names) + ' · ' + esc(x.ip)) +
      list('r_noplay', r.no_play, x => '<b>' + esc(x.username) + '</b> · ' + x.ads + ' ' + T('ads')) +
      list('r_max', r.maxed, x => '<b>' + esc(x.username) + '</b> · ' + x.days + ' ' + T('days_n')) +
      list('r_new', r.new_heavy, x => '<b>' + esc(x.username) + '</b> · ' + x.ads + ' ' + T('ads')) +
      list('r_log', r.log, x => '<b>' + esc(x.username) + '</b> · ' + esc(x.action) + ' · ' + esc(x.target) + (x.details ? ' · ' + esc(x.details) : '') + ' · ' + esc(String(x.created_at).slice(0, 16)));
  }

  function render() {
    tabs();
    if (tab === 'overview') viewOverview();
    else if (tab === 'risk') viewRisk();
    else viewUsers('');
  }

  document.addEventListener('DOMContentLoaded', async () => {
    document.querySelectorAll('[data-lang]').forEach(b => b.addEventListener('click', () => I18n.setLang(b.dataset.lang)));
    document.addEventListener('langchange', render);
    I18n.apply();
    const me = await Api.call('auth/me');
    if (!me.ok || !me.user.is_admin) { location.replace('index.html'); return; }
    render();
  });
})();
