// يعمل فقط داخل تطبيق Capacitor (بعد تثبيت @capacitor-community/admob وتشغيل npm run android).
// خارج التطبيق (المتصفح العادي) هذا الملف لا يفعل شيئاً، فلا يؤثر على تجربة الموقع كما هي.
// يربط الإعلان المكافئ الحقيقي بواجهة window.AdmobBridge.showRewarded التي يتوقعها assets/js/ads.js.
(function () {
  'use strict';
  if (!window.Capacitor || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) return;

  const AdMob = Capacitor.Plugins && Capacitor.Plugins.AdMob;
  if (!AdMob) { console.warn('[admob-bridge] AdMob plugin not found. Did you run npm run android (cap sync)?'); return; }

  const cfg = window.APP_CONFIG || {};
  let ready = AdMob.initialize({
    testingDevices: cfg.ADMOB_TEST_DEVICES || [],
    initializeForTesting: !!cfg.ADMOB_TEST_MODE,
  }).catch(e => console.error('[admob-bridge] initialize failed', e));

  // معرّف الإعلان التجريبي الرسمي من جوجل (يعمل دائماً بدون حساب). استبدله بمعرّفك الحقيقي في config.js قبل النشر.
  const TEST_AD_UNIT = 'ca-app-pub-3940256099942544/5224354917';

  async function showRewarded({ userId, customData }) {
    await ready;
    const adId = cfg.ADMOB_TEST_MODE ? TEST_AD_UNIT : (cfg.ADMOB_REWARDED_ID || TEST_AD_UNIT);
    try {
      await AdMob.prepareRewardVideoAd({
        adId,
        isTesting: !!cfg.ADMOB_TEST_MODE,
        // ssv يرسل هذين الحقلين مع إشعار التحقق الحقيقي إلى api/ssv.php. لا يعمل على إعلانات الاختبار (isTesting=true) — هذا سلوك AdMob نفسه.
        ssv: { userId: String(userId), customData: String(customData) },
      });
      await AdMob.showRewardVideoAd();   // يرفض (throw) إذا أغلق المستخدم الإعلان قبل انتهائه أو فشل العرض
      return true;
    } catch (e) {
      console.warn('[admob-bridge] rewarded ad not completed', e);
      return false;
    }
  }

  window.AdmobBridge = { showRewarded };
})();
