// طبقة الإعلانات: مزوّد 'dev' (إعلان تجريبي) الآن، ثم 'admob' عند التغليف كتطبيق أندرويد.
// لتغيير المزوّد ضع في config.js: AD_PROVIDER: 'admob'
(function () {
  'use strict';
  const isNative = !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  const cfgProvider = (window.APP_CONFIG && APP_CONFIG.AD_PROVIDER) || 'auto';
  const provider = cfgProvider === 'auto' ? (isNative ? 'admob' : 'dev') : cfgProvider;
  // SSV الحقيقي لا يصل أبداً لإعلانات AdMob التجريبية (isTesting/ADMOB_TEST_MODE)، فنستخدم نفس مسار الاعتماد اليدوي كما في وضع dev
  const needsDevComplete = provider === 'dev' || (provider === 'admob' && window.APP_CONFIG && APP_CONFIG.ADMOB_TEST_MODE);
  const AD_SECONDS = 5;
  let styled = false;

  function injectStyle() {
    if (styled) return; styled = true;
    const s = document.createElement('style');
    s.textContent = `
.ad-ov{position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;background:rgba(5,10,28,.94);font-family:system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif}
.ad-box{position:relative;width:min(86vw,320px);padding:26px 20px 20px;text-align:center;color:#fff;background:#14213f;border:1px solid #33478a;border-radius:16px}
.ad-x{position:absolute;top:6px;inset-inline-end:10px;border:0;background:transparent;color:#a9b8e0;font-size:1.6rem;line-height:1;cursor:pointer}
.ad-tag{display:inline-block;padding:2px 10px;border-radius:8px;background:#f2b21a;color:#2a1d00;font-weight:800;font-size:.8rem}
.ad-count{font-size:3.4rem;font-weight:900;color:#f2b21a;margin:10px 0 6px;font-variant-numeric:tabular-nums}
.ad-bar{height:8px;border-radius:4px;background:#0b1430;overflow:hidden}
.ad-bar i{display:block;height:100%;width:0;background:#63b817;transition:width 1s linear}
.ad-note{color:#a9b8e0;font-size:.85rem;margin:14px 0}
.ad-claim{width:100%;padding:11px;border:0;border-radius:10px;background:#f2b21a;color:#2a1d00;font-weight:800;font-size:1rem;cursor:pointer}
.ad-claim:disabled{opacity:.4;cursor:default}`;
    document.head.appendChild(s);
  }

  // مزوّد المحاكاة: يرجع true عند استلام المكافأة، false عند الإغلاق المبكر
  function devAd() {
    injectStyle();
    return new Promise(resolve => {
      const ov = document.createElement('div');
      ov.className = 'ad-ov';
      ov.innerHTML = '<div class="ad-box"><button type="button" class="ad-x">×</button>' +
        '<span class="ad-tag"></span><div class="ad-count"></div><div class="ad-bar"><i></i></div>' +
        '<p class="ad-note"></p><button type="button" class="ad-claim" disabled></button></div>';
      const q = s => ov.querySelector(s);
      q('.ad-tag').textContent = I18n.t('ad_test');
      q('.ad-note').textContent = I18n.t('ad_test_note');
      q('.ad-claim').textContent = I18n.t('ad_claim');
      let left = AD_SECONDS;
      q('.ad-count').textContent = left;
      document.body.appendChild(ov);
      requestAnimationFrame(() => { q('.ad-bar i').style.width = (100 / AD_SECONDS) + '%'; });
      const timer = setInterval(() => {
        left--; q('.ad-count').textContent = Math.max(left, 0);
        q('.ad-bar i').style.width = (100 * (AD_SECONDS - left) / AD_SECONDS) + '%';
        if (left <= 0) { clearInterval(timer); q('.ad-claim').disabled = false; }
      }, 1000);
      const end = ok => { clearInterval(timer); ov.remove(); resolve(ok); };
      q('.ad-x').addEventListener('click', () => end(false));
      q('.ad-claim').addEventListener('click', () => end(true));
    });
  }

  // مزوّد AdMob (لاحقاً): جسر Capacitor يعرض الإعلان المكافئ ويمرّر userId و customData=nonce
  function admobAd(nonce, userId) {
    if (window.AdmobBridge && AdmobBridge.showRewarded) return AdmobBridge.showRewarded({ userId: String(userId), customData: nonce });
    return Promise.resolve(false);
  }

  const providers = { dev: devAd, admob: admobAd };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function status() { return Api.call('ads/status'); }

  async function watch(placement) {
    const req = await Api.call('ads/request', 'POST', { placement: placement || 'home' });
    if (!req.ok) return req;

    const shown = await (providers[provider] || devAd)(req.nonce, req.user_id);
    if (!shown) {
      await Api.call('ads/cancel', 'POST', { nonce: req.nonce });
      return { ok: false, message: I18n.t('ad_cancelled') };
    }
    // في وضع dev نحاكي إشعار جوجل؛ في الإنتاج يصل الإشعار من جوجل إلى الخادم وحده
    if (needsDevComplete) {
      const d = await Api.call('ads/dev_complete', 'POST', { nonce: req.nonce });
      if (!d.ok) return d;
    }
    // ننتظر أن يعتمد الخادم المشاهدة قبل منح أي مكافأة
    for (let i = 0; i < 8; i++) {
      const c = await Api.call('ads/check', 'POST', { nonce: req.nonce });
      if (!c.ok) return c;
      if (c.status === 'verified') return { ok: true };
      if (c.status !== 'requested') return { ok: false, message: I18n.t('ad_failed') };
      await sleep(1500);
    }
    return { ok: false, message: I18n.t('ad_pending') };
  }

  window.Ads = { status, watch, provider };
})();
