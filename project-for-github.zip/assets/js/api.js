(function () {
  function deviceId() {
    let id = localStorage.getItem('device_id');
    if (!id || !/^[A-Za-z0-9\-_]{16,128}$/.test(id)) {
      id = (window.crypto && crypto.randomUUID)
        ? crypto.randomUUID()
        : 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
      localStorage.setItem('device_id', id);
    }
    return id;
  }
  const token = () => localStorage.getItem('token');
  const setToken = t => t ? localStorage.setItem('token', t) : localStorage.removeItem('token');

  function fail(debug) {
    if (window.Debug) Debug.show('API: ' + debug);
    return { ok: false, message: I18n.t('network_error'), debug };
  }

  async function call(route, method, body) {
    const headers = { 'X-Lang': I18n.lang() };
    const tk = token();
    if (tk) headers['X-Auth-Token'] = tk;
    const opt = { method: method || 'GET', headers };
    if (body) { headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    try {
      const res = await fetch(APP_CONFIG.API_BASE + '?r=' + encodeURIComponent(route), opt);
      const text = await res.text();
      try { return JSON.parse(text); }
      catch (e) { return fail('HTTP ' + res.status + ' ' + route + ': ' + (text.slice(0, 200) || '(empty)')); }
    } catch (e) {
      return fail(route + ': ' + e.message);
    }
  }

  window.Api = { call, deviceId, token, setToken };
})();
