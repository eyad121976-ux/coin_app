(function () {
  const $ = s => document.querySelector(s);
  let mode = 'login';

  function msg(text, type) {
    const m = $('#msg');
    if (!text) { m.className = 'alert d-none mt-3'; return; }
    m.className = 'alert alert-' + (type || 'danger') + ' mt-3';
    m.textContent = text;
  }

  function setMode(m) {
    mode = m;
    $('#tab-login').classList.toggle('active', m === 'login');
    $('#tab-register').classList.toggle('active', m === 'register');
    $('#email-group').classList.toggle('d-none', m !== 'register');
    $('#submit').dataset.i18n = m === 'login' ? 'submit_login' : 'submit_register';
    $('#password').autocomplete = m === 'login' ? 'current-password' : 'new-password';
    msg('');
    I18n.apply();
  }

  function showHome(user) {
    $('#auth').classList.add('d-none');
    $('#home').classList.remove('d-none');
    $('#who').textContent = user.username;
    $('#admin-link').classList.toggle('d-none', !user.is_admin);
    $('#balance').textContent = '🪙 ' + (user.coins || 0);
    document.dispatchEvent(new Event('homeshown'));
  }

  function showAuth() {
    $('#home').classList.add('d-none');
    $('#auth').classList.remove('d-none');
  }

  async function onSubmit(e) {
    e.preventDefault();
    msg('');
    const btn = $('#submit');
    btn.disabled = true;
    const body = {
      username: $('#username').value.trim(),
      password: $('#password').value,
      device_id: Api.deviceId(),
      lang: I18n.lang()
    };
    if (mode === 'register') body.email = $('#email').value.trim();
    const r = await Api.call(mode === 'login' ? 'auth/login' : 'auth/register', 'POST', body);
    btn.disabled = false;
    if (!r.ok) return msg((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : ''));
    Api.setToken(r.token);
    $('#password').value = '';
    showHome(r.user);
  }

  async function boot() {
    I18n.apply();
    setMode('login');
    if (!Api.token()) return showAuth();
    const r = await Api.call('auth/me');
    if (r.ok) showHome(r.user); else { Api.setToken(null); showAuth(); }
  }

  document.addEventListener('DOMContentLoaded', () => {
    $('#form').addEventListener('submit', onSubmit);
    $('#tab-login').addEventListener('click', () => setMode('login'));
    $('#tab-register').addEventListener('click', () => setMode('register'));
    $('#logout').addEventListener('click', async () => {
      await Api.call('auth/logout', 'POST', {});
      Api.setToken(null);
      showAuth();
    });
    document.querySelectorAll('[data-lang]').forEach(b =>
      b.addEventListener('click', () => I18n.setLang(b.dataset.lang)));
    document.addEventListener('langchange', e => {
      if (Api.token()) Api.call('auth/lang', 'POST', { lang: e.detail });
    });
    boot();
  });
})();
