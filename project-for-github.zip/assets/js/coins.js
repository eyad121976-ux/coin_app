(function () {
  'use strict';
  if (!Api.token()) { location.replace('index.html'); return; }

  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let sum = null, items = [], nextBefore = null;
  const ITEMS = ['bomb', 'shake', 'big', 'rescue', 'continue'];
  const ICON = { bomb: '💣', shake: '🌀', big: '⭐', rescue: '🛟', continue: '▶' };

  function msg(text, type) {
    const m = $('#c-msg');
    if (!text) { m.className = 'alert d-none mt-2'; return; }
    m.className = 'alert alert-' + (type || 'danger') + ' mt-2'; m.textContent = text;
  }

  function renderSummary() {
    if (!sum) return;
    $('#c-coins').textContent = '🪙 ' + sum.coins;
    $('#c-bar').style.width = Math.min(100, sum.game_cap > 0 ? sum.game_today / sum.game_cap * 100 : 0) + '%';
    $('#c-today').textContent = I18n.t('game_today_note').replace('{a}', sum.game_today).replace('{b}', sum.game_cap);
    $('#c-earn').innerHTML =
      '<li>' + esc(I18n.t('earn_ad').replace('{n}', sum.coins_per_ad)) + '</li>' +
      '<li>' + esc(I18n.t('earn_play').replace('{d}', sum.score_divisor)) + '</li>' +
      '<li>' + esc(I18n.t('earn_daily').replace('{n}', sum.daily_bonus)) + '</li>';
    const b = $('#c-daily');
    b.disabled = sum.daily_claimed;
    b.textContent = sum.daily_claimed ? I18n.t('claimed_today') : I18n.t('claim_daily') + ' (+' + sum.daily_bonus + ')';
    $('#c-shop').innerHTML = ITEMS.map(k =>
      '<div class="d-flex justify-content-between py-2 border-bottom" style="border-color:#33478a!important"><span>' + ICON[k] + ' ' +
      esc(k === 'continue' ? I18n.t('continue_item') : I18n.t('perk_' + k)) + '</span><b>🪙 ' + esc(sum.prices[k]) + '</b></div>').join('');
  }

  function renderList() {
    const box = $('#c-list');
    box.innerHTML = items.length ? items.map(x =>
      '<div class="d-flex justify-content-between align-items-center py-2 border-bottom" style="border-color:#33478a!important">' +
      '<div><div>' + esc(I18n.t('ctx_' + x.type)) + (x.note && x.type === 'purchase' ? ' · ' + esc(I18n.t('perk_' + x.note) === 'perk_' + x.note ? x.note : I18n.t('perk_' + x.note)) : '') + '</div>' +
      '<div class="note">' + esc(String(x.at).slice(0, 16)) + '</div></div>' +
      '<div dir="ltr" class="fw-bold ' + (x.amount < 0 ? 'text-danger' : 'text-success') + '">' + (x.amount > 0 ? '+' : '') + x.amount + ' 🪙</div></div>').join('')
      : '<div class="note">' + I18n.t('no_history') + '</div>';
    $('#c-more').classList.toggle('d-none', !nextBefore);
  }

  async function loadLedger(before) {
    const r = await Api.call('coins/ledger', 'POST', before ? { before } : {});
    if (!r.ok) return;
    items = before ? items.concat(r.items) : r.items;
    nextBefore = r.next_before;
    renderList();
  }

  async function load() {
    const r = await Api.call('coins/summary');
    if (!r.ok) {
      if (r.error === 'err_unauth') { Api.setToken(null); location.replace('index.html'); return; }
      return msg((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : ''));
    }
    sum = r; renderSummary();
  }

  async function claim() {
    msg('');
    const r = await Api.call('coins/claim_daily', 'POST', {});
    if (!r.ok) { msg(r.message || I18n.t('network_error')); return load(); }
    msg(I18n.t('daily_ok').replace('{n}', r.bonus), 'success');
    await load(); loadLedger(0);
  }

  document.addEventListener('DOMContentLoaded', () => {
    I18n.apply();
    document.querySelectorAll('[data-lang]').forEach(b => b.addEventListener('click', () => I18n.setLang(b.dataset.lang)));
    $('#c-daily').addEventListener('click', claim);
    $('#c-more').addEventListener('click', () => loadLedger(nextBefore));
    load(); loadLedger(0);
  });
  document.addEventListener('langchange', () => { renderSummary(); renderList(); });
})();
