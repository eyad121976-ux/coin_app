// شريط أخطاء أحمر أسفل الشاشة أثناء الاختبار (لتشخيص المشاكل من الهاتف بدون console).
// اضغط عليه لإخفائه. لإيقافه: DEBUG: false في config.js
(function () {
  'use strict';
  window.APP_BUILD = 15;
  if (window.APP_CONFIG && APP_CONFIG.DEBUG === false) return;
  function show(msg) {
    let b = document.getElementById('dbg');
    if (!b) {
      b = document.createElement('div'); b.id = 'dbg';
      b.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:9999;max-height:40vh;overflow:auto;padding:8px 12px;' +
        'background:#7a0f0f;color:#fff;font:12px/1.4 monospace;direction:ltr;text-align:left;white-space:pre-wrap';
      b.addEventListener('click', () => b.remove());
      document.body.appendChild(b);
    }
    b.textContent += (b.textContent ? '\n' : '') + msg;
  }
  window.addEventListener('error', e => {
    const t = e.target;
    if (t && t !== window && (t.src || t.href)) show('Failed to load: ' + (t.src || t.href));
    else show('JS error: ' + e.message + ' @' + String(e.filename || '').split('/').pop() + ':' + e.lineno);
  }, true);
  window.addEventListener('unhandledrejection', e => show('Promise error: ' + ((e.reason && e.reason.message) || e.reason)));
  window.Debug = { show };

  // رقم النسخة (للتأكد أن المتصفح حمّل الملفات الجديدة) + كشف الملفات القديمة
  window.addEventListener('load', () => {
    const tag = document.createElement('div');
    tag.textContent = 'build ' + window.APP_BUILD;
    tag.style.cssText = 'position:fixed;top:2px;right:6px;z-index:9998;font:10px monospace;color:#fff;opacity:.35;pointer-events:none';
    document.body.appendChild(tag);
    if (window.I18n && I18n.t('ad_go') === 'ad_go') {
      show('ملفات قديمة: i18n.js لا يحتوي مفاتيح الإعلانات. أعد رفع الحزمة الكاملة أو افتح الصفحة في نافذة التصفح الخفي.');
    }
  });
})();
