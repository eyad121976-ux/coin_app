(function () {
  'use strict';
  if (!Api.token()) { location.replace('index.html'); return; }

  const { Engine, Bodies, Body, Composite, Events } = Matter;

  // ---------- الثوابت ----------
  const W = 360, H = 600, WALL = 60, DROP_Y = 52, DANGER_Y = 118, STEP = 1000 / 60;
  // سرعة الحركة: قلّل الرقمين لإبطاء اللعبة أكثر، وزدهما لتسريعها (كانت 1.15 و7)
  const GRAVITY = 0.85, LAUNCH_SPEED = 5.5;
  const ORIGIN_X = W / 2, MAX_ANGLE = 65 * Math.PI / 180;
  const LEVELS = [
    { v: 2,    r: 14, c: ['#c87941', '#efb07a', '#7a4322'], t: '#fff' },
    { v: 5,    r: 18, c: ['#a5622f', '#d18a52', '#5f3417'], t: '#fff' },
    { v: 10,   r: 22, c: ['#8fa3ff', '#d2dbff', '#4a5cc4'], t: '#fff' },
    { v: 20,   r: 27, c: ['#e9855a', '#ffb896', '#a24b28'], t: '#fff' },
    { v: 50,   r: 33, c: ['#f4c542', '#ffe58f', '#b8860b'], t: '#3b2a00' },
    { v: 100,  r: 40, c: ['#d9dde8', '#ffffff', '#8a93a8'], t: '#2a3350' },
    { v: 200,  r: 48, c: ['#7fb1ff', '#d3e6ff', '#3f6fc0'], t: '#fff' },
    { v: 500,  r: 57, c: ['#f2a900', '#ffdb6a', '#a86a00'], t: '#3b2400' },
    { v: 1000, r: 67, c: ['#d2451e', '#ff916a', '#7c1f08'], t: '#ffe58f' }
  ];
  const MAX_L = LEVELS.length - 1;
  const SPAWN_W = [40, 30, 20, 10];          // أوزان ظهور المستويات 0..3
  const JACKPOT = 2000;
  const START_TARGET = 300, TARGET_STEP = 100, TARGET_MAX = 800;
  const PERK_ICON = { bomb: '💣', shake: '🌀', big: '⭐', rescue: '🛟' };
  const WHEEL = ['bomb', 'shake', 'big', 'rescue', 'bomb', 'shake', 'big', 'rescue'];
  const WHEEL_COL = ['#2d4a9a', '#1c2d66'];

  // ---------- عناصر ----------
  const $ = s => document.querySelector(s);
  const board = $('#board'), ctx = board.getContext('2d');
  const nctx = $('#next').getContext('2d');
  const wheelEl = $('#wheel');

  let engine, st, mergeQ = [], particles = [], floaters = [];
  let best = 0, sessionId = null, lastSid = null, finishP = null;
  let coins = 0, buying = false, prices = { bomb: 120, shake: 80, big: 150, rescue: 100, continue: 200 };
  let last = 0, acc = 0;
  let wheelRot = 0, spinning = false;

  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function pickLevel() {
    let r = Math.random() * SPAWN_W.reduce((a, b) => a + b, 0);
    for (let i = 0; i < SPAWN_W.length; i++) { r -= SPAWN_W[i]; if (r <= 0) return i; }
    return 0;
  }
  const allCoins = () => Composite.allBodies(engine.world).filter(b => b.label === 'coin');

  // ---------- رسم العملة ----------
  function drawCoin(c, x, y, r, lv, ang, sc) {
    const L = LEVELS[lv]; r *= sc || 1;
    c.save(); c.translate(x, y); c.rotate(ang || 0);
    const g = c.createRadialGradient(-r * .35, -r * .4, r * .1, 0, 0, r);
    g.addColorStop(0, L.c[1]); g.addColorStop(.55, L.c[0]); g.addColorStop(1, L.c[2]);
    c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.fillStyle = g; c.fill();
    c.lineWidth = Math.max(1.5, r * .08); c.strokeStyle = L.c[2]; c.stroke();
    c.beginPath(); c.arc(0, 0, r * .78, 0, Math.PI * 2);
    c.lineWidth = Math.max(1, r * .04); c.strokeStyle = 'rgba(255,255,255,.45)'; c.stroke();
    const s = String(L.v);
    const fs = r * (s.length >= 4 ? .62 : s.length === 3 ? .78 : .95);
    c.font = '900 ' + fs + 'px "Arial Black", Impact, system-ui, sans-serif';
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
    c.lineWidth = Math.max(2, fs * .14); c.strokeStyle = 'rgba(0,0,0,.45)';
    c.strokeText(s, 0, fs * .04); c.fillStyle = L.t; c.fillText(s, 0, fs * .04);
    c.restore();
  }
  function drawNext() {
    nctx.clearRect(0, 0, 64, 64);
    drawCoin(nctx, 32, 32, LEVELS[st.next].r, st.next, 0, 1);
  }

  // ---------- الفيزياء ----------
  function spawnCoin(x, y, lv, vx, vy, pop) {
    const L = LEVELS[lv];
    const b = Bodies.circle(x, y, L.r, {
      restitution: .12, friction: .25, frictionStatic: .6, frictionAir: .004, density: .0012, label: 'coin'
    });
    b.lv = lv; b.born = st.time; b.over = 0; b.pop = pop ? 1 : 0; b.dead = false;
    Body.setVelocity(b, { x: vx || 0, y: vy || 0 });
    Composite.add(engine.world, b);
    return b;
  }

  function onCollide(e) {
    for (const p of e.pairs) {
      const a = p.bodyA, b = p.bodyB;
      if (a.label === 'coin' && b.label === 'coin' && a.lv === b.lv && !a.dead && !b.dead) {
        a.dead = b.dead = true;
        mergeQ.push([a, b]);
      }
    }
  }

  function fx(x, y, color, n) {
    for (let i = 0; i < n; i++)
      particles.push({ x, y, vx: rnd(-110, 110), vy: rnd(-170, 20), life: rnd(.4, .8), color, size: rnd(2, 4.5) });
  }
  function floater(x, y, text, color) { floaters.push({ x, y, text, color, life: .9 }); }

  function processMerges() {
    while (mergeQ.length) {
      const [a, b] = mergeQ.shift();
      Composite.remove(engine.world, a); Composite.remove(engine.world, b);
      const x = (a.position.x + b.position.x) / 2, y = (a.position.y + b.position.y) / 2;
      let gained;
      if (a.lv >= MAX_L) {
        gained = JACKPOT;
        fx(x, y, '#ffd75e', 24); floater(x, y, I18n.t('jackpot') + ' +' + gained, '#ffd75e');
      } else {
        const nb = spawnCoin(x, y, a.lv + 1, (a.velocity.x + b.velocity.x) / 2, (a.velocity.y + b.velocity.y) / 2, true);
        gained = LEVELS[a.lv + 1].v;
        st.maxLevel = Math.max(st.maxLevel, a.lv + 1);
        fx(x, y, LEVELS[a.lv + 1].c[1], 10 + a.lv); floater(x, y - nb.circleRadius, '+' + gained, '#fff');
      }
      st.score += gained; st.bar += gained; st.merges++;
      st.combo = (st.time - st.comboAt < 1000) ? st.combo + 1 : 1;
      st.comboAt = st.time;
      if (st.combo >= 2) st.banner = { key: st.combo === 2 ? 'good' : st.combo === 3 ? 'great' : 'amazing', t: 1 };
      st.lastMergeAt = st.time;
      if (gained >= 200) considerOffer('double', gained);
      else if (st.maxLevel >= 5 && st.maxLevel > st.milestoneDone) { st.milestoneDone = st.maxLevel; considerOffer('milestone'); }
      if (navigator.vibrate) navigator.vibrate(8);
    }
    updateHud();
  }

  function checkDanger() {
    let any = false, minTop = H, n = 0;
    for (const b of allCoins()) {
      n++;
      if (st.time - b.born < 1500) { b.over = 0; continue; }
      const top = b.position.y - LEVELS[b.lv].r;
      if (b.speed < .8) minTop = Math.min(minTop, top);
      if (top < DANGER_Y && b.speed < .8) {
        b.over += STEP; any = true;
        if (b.over > 2000) { gameOver(); return; }
      } else b.over = 0;
    }
    st.warn = any;
    // تعثر: الكومة اقتربت من الخط، أو لا دمج منذ فترة طويلة والحاوية ممتلئة نسبياً
    st.nearFor = minTop < DANGER_Y + 70 ? st.nearFor + STEP : 0;
    const stuck = n >= 14 && st.time - st.lastMergeAt > 20000;
    if ((st.nearFor > 1500 || stuck) && st.rescueOffers < 2) considerOffer('rescue');
  }

  function afterStep() {
    st.time += STEP;
    if (mergeQ.length) processMerges();
    checkDanger();
  }

  // ---------- اللعب ----------
  // اتجاه الإطلاق: من نقطة الإسقاط (أعلى الوسط) نحو مكان الإصبع
  function aimVector() {
    const dx = st.aimX - ORIGIN_X, dy = Math.max(st.aimY - DROP_Y, 40);
    const a = clamp(Math.atan2(dx, dy), -MAX_ANGLE, MAX_ANGLE);
    return { vx: Math.sin(a) * LAUNCH_SPEED, vy: Math.cos(a) * LAUNCH_SPEED };
  }

  // محاكاة المسار المتوقع بنفس ثوابت الفيزياء (جاذبية، مقاومة هواء، ارتداد الجدران)
  function predictPath() {
    const r = LEVELS[st.cur].r, v = aimVector();
    const g = engine.gravity.y * (engine.gravity.scale || .001) * STEP * STEP;
    const air = 1 - .004, coins = allCoins();
    let x = ORIGIN_X, y = DROP_Y, vx = v.vx, vy = v.vy;
    const pts = [];
    for (let i = 0; i < 240; i++) {
      vx *= air; vy = vy * air + g; x += vx; y += vy;
      if (x < r) { x = r; vx = -vx * .12; } else if (x > W - r) { x = W - r; vx = -vx * .12; }
      let hit = y + r >= H;
      if (hit) y = H - r;
      else for (const c of coins) {
        const dx = x - c.position.x, dy = y - c.position.y, rr = r + LEVELS[c.lv].r;
        if (dx * dx + dy * dy < rr * rr) { hit = true; break; }
      }
      pts.push({ x, y });
      if (hit) break;
    }
    return pts;
  }

  function drop() {
    if (!st || !st.running || st.time < st.readyAt) return;
    const v = aimVector();
    spawnCoin(ORIGIN_X, DROP_Y, st.cur, v.vx, v.vy, false);
    st.readyAt = st.time + 500;
    st.cur = st.next; st.next = pickLevel(); drawNext();
  }

  function usePerk(k) {
    if (!st.running || st.perks[k] <= 0) return;
    const coins = allCoins();
    if (k === 'bomb') {
      if (!coins.length) return;
      coins.sort((a, b) => a.lv - b.lv || b.position.y - a.position.y).slice(0, 4).forEach(b => {
        fx(b.position.x, b.position.y, '#ff9a3c', 10); Composite.remove(engine.world, b);
      });
    } else if (k === 'shake') {
      if (!coins.length) return;
      coins.forEach(b => Body.setVelocity(b, { x: rnd(-5, 5), y: -rnd(4, 9) }));
    } else if (k === 'big') {
      st.cur = 5;
    } else if (k === 'rescue') {
      if (!coins.length) return;
      coins.sort((a, b) => a.position.y - b.position.y).slice(0, 3).forEach(b => {
        fx(b.position.x, b.position.y, '#7fe3ff', 10); Composite.remove(engine.world, b);
      });
    }
    st.perks[k]--; updateHud();
  }

  function paintContinue() {
    $('#continue-btn').classList.toggle('hidden', st.usedContinue || adLeft <= 0);
    const cb = $('#continue-coins-btn');
    cb.textContent = I18n.t('continue_coins').replace('{n}', prices.continue);
    cb.classList.toggle('hidden', st.usedContinue || coins < prices.continue);
  }

  async function gameOver() {
    if (st.over) return;
    st.over = true; st.running = false;
    hideOffer();
    const final = st.score, isRecord = final > best;
    best = Math.max(best, final);
    $('#over-score').textContent = final;
    $('#over-best').textContent = best;
    $('#over-record').classList.toggle('hidden', !isRecord);
    $('#over-coins').textContent = '';
    paintContinue();
    $('#over-modal').classList.remove('hidden');
    updateHud();
    const sid = sessionId; sessionId = null; lastSid = sid;
    if (sid) {
      finishP = Api.call('game/finish', 'POST', { session_id: sid, score: final, merges: st.merges, max_level: st.maxLevel });
      const r = await finishP;
      if (r.ok) {
        if (r.best) { best = Math.max(best, r.best); $('#over-best').textContent = best; }
        if (typeof r.coins === 'number') { coins = r.coins; $('#coins').textContent = coins; }
        if (r.coins_awarded > 0) $('#over-coins').textContent = I18n.t('over_coins') + ': +' + r.coins_awarded + ' 🪙';
        paintContinue();
      }
    }
  }

  async function newGame() {
    $('#over-modal').classList.add('hidden');
    $('#wheel-modal').classList.add('hidden');
    hideOffer(); lastSid = null; finishP = null;
    engine = Engine.create({ positionIterations: 10, velocityIterations: 8 });
    engine.gravity.y = GRAVITY;
    mergeQ = []; particles = []; floaters = [];
    const o = { isStatic: true, friction: .4, label: 'wall' };
    Composite.add(engine.world, [
      Bodies.rectangle(W / 2, H + WALL / 2, W + WALL * 2, WALL, o),
      Bodies.rectangle(-WALL / 2, H / 2, WALL, H * 2, o),
      Bodies.rectangle(W + WALL / 2, H / 2, WALL, H * 2, o)
    ]);
    Events.on(engine, 'collisionStart', onCollide);
    st = {
      score: 0, merges: 0, maxLevel: 0, bar: 0, target: START_TARGET, time: 0, readyAt: 0,
      running: true, over: false, warn: false, aimX: W / 2, aimY: H, cur: pickLevel(), next: pickLevel(),
      perks: { bomb: 0, shake: 0, big: 0, rescue: 0 }, combo: 0, comboAt: -9999, banner: null,
      usedContinue: false, nearFor: 0, lastMergeAt: 0, offerGap: 20000, rescueOffers: 0, milestoneDone: 4
    };
    acc = 0;
    updateHud(); drawNext();
    const r = await Api.call('game/start', 'POST', {});
    if (r.ok) { sessionId = r.session_id; best = Math.max(best, r.best || 0); }
    else if (r.error === 'err_unauth') { Api.setToken(null); location.replace('index.html'); return; }
    updateHud();
  }

  // ---------- العجلة ----------
  function drawWheelFace() {
    const c = wheelEl.getContext('2d'), R = 240, seg = Math.PI * 2 / WHEEL.length;
    c.clearRect(0, 0, 480, 480);
    for (let i = 0; i < WHEEL.length; i++) {
      const a0 = -Math.PI / 2 + i * seg;
      c.beginPath(); c.moveTo(R, R); c.arc(R, R, R - 6, a0, a0 + seg); c.closePath();
      c.fillStyle = WHEEL_COL[i % 2]; c.fill();
      c.lineWidth = 3; c.strokeStyle = '#f2b21a'; c.stroke();
      c.save(); c.translate(R, R); c.rotate(a0 + seg / 2);
      c.font = '64px system-ui, "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
      c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(PERK_ICON[WHEEL[i]], R * .62, 0);
      c.restore();
    }
    c.beginPath(); c.arc(R, R, 26, 0, Math.PI * 2); c.fillStyle = '#f2b21a'; c.fill();
  }

  function openWheel() {
    if (!st.running || st.bar < st.target) return;
    st.running = false; hideOffer();
    $('#wheel-result').textContent = '';
    $('#spin-btn').disabled = false;
    $('#wheel-close').classList.remove('hidden');
    $('#wheel-ad').classList.add('hidden');
    $('#wheel-modal').classList.remove('hidden');
  }
  function closeWheel() {
    if (spinning) return;
    $('#wheel-modal').classList.add('hidden');
    if (!st.over) st.running = true;
  }
  // free = دورة إضافية بعد إعلان (لا تستهلك نقاط الشريط)
  function spin(free) {
    if (spinning) return;
    spinning = true;
    $('#spin-btn').disabled = true;
    $('#wheel-close').classList.add('hidden'); $('#wheel-ad').classList.add('hidden');
    const i = Math.floor(Math.random() * WHEEL.length), segDeg = 360 / WHEEL.length;
    const target = (360 - (i + .5) * segDeg + rnd(-segDeg * .35, segDeg * .35) + 360) % 360;
    const cur = ((wheelRot % 360) + 360) % 360;
    wheelRot += 360 * 5 + ((target - cur + 360) % 360);
    wheelEl.style.transform = 'rotate(' + wheelRot + 'deg)';
    setTimeout(() => {
      const k = WHEEL[i];
      st.perks[k]++;
      if (!free) { st.bar -= st.target; st.target = Math.min(TARGET_MAX, st.target + TARGET_STEP); }
      $('#wheel-result').textContent = I18n.t('wheel_won') + PERK_ICON[k] + ' ' + I18n.t('perk_' + k);
      spinning = false; updateHud();
      $('#wheel-close').classList.remove('hidden');
      $('#wheel-ad').classList.toggle('hidden', adLeft <= 0);
    }, 4200);
  }

  // ---------- الإعلانات (كلها اختيارية: اللاعب هو من يضغط) ----------
  let adBusy = false, toastT = 0, offerT = 0, adLeft = 1, curOffer = null;
  const PERK_KEYS = ['bomb', 'shake', 'big', 'rescue'];
  const OFFERS = {
    rescue:    { icon: '🛟', key: 'offer_rescue' },
    double:    { icon: '✨', key: 'offer_double' },
    milestone: { icon: '🎁', key: 'offer_milestone' }
  };

  function toast(text) {
    const t = $('#toast'); t.textContent = text; t.classList.remove('hidden');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.add('hidden'), 2800);
  }
  async function updateAdBtn() {
    const s = await Ads.status();
    if (s.ok) { adLeft = s.daily_limit - s.today_verified; $('#ad-count').textContent = s.today_verified + '/' + s.daily_limit; }
  }
  function grantPerk() {
    const k = PERK_KEYS[Math.floor(Math.random() * PERK_KEYS.length)];
    st.perks[k]++; floater(W / 2, H * .45, '🎁 ' + PERK_ICON[k] + ' +1', '#ffd75e'); updateHud();
  }
  function removeTop(n, alsoZone) {
    const cs = allCoins().sort((a, b) => a.position.y - b.position.y);
    cs.forEach((b, i) => {
      const inZone = alsoZone && (b.position.y - LEVELS[b.lv].r) < DANGER_Y + 40;
      if (i < n || inZone) { fx(b.position.x, b.position.y, '#7fe3ff', 10); Composite.remove(engine.world, b); }
    });
    st.warn = false; st.nearFor = 0; st.lastMergeAt = st.time;
  }
  function setAdButtons(disabled) {
    ['#ad-btn', '#continue-btn', '#wheel-ad', '#offer-go'].forEach(s => { $(s).disabled = disabled; });
  }

  // يوقف اللعبة، يعرض الإعلان، يعيد الحالة كما كانت، ثم يمنح المكافأة فقط بعد اعتماد الخادم
  async function runAd(placement, onReward) {
    if (adBusy || !st) return false;
    adBusy = true; const prev = st.running; st.running = false; setAdButtons(true);
    const r = await Ads.watch(placement);
    adBusy = false; setAdButtons(false); st.running = prev;
    if (r.ok) {
      onReward();
      refreshCoins().then(g => { if (g > 0) floater(W / 2, H * .55, '+' + g + ' 🪙', '#ffd75e'); });
    } else toast((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : ''));
    updateAdBtn();
    return r.ok;
  }

  // زر "شاهد إعلاناً = مزية مجانية" الدائم
  function watchAd() {
    if (!st || st.over || !st.running) return;
    runAd('perk', () => {});
  }

  // عروض اللحظات المناسبة: بطاقة صغيرة غير مانعة، تختفي بعد 9 ثوانٍ ولا تتكرر أكثر من مرة كل 45 ثانية
  function offerVisible() { return !$('#offer').classList.contains('hidden'); }
  function hideOffer() { $('#offer').classList.add('hidden'); clearTimeout(offerT); curOffer = null; }
  function considerOffer(kind, n) {
    if (!st.running || adLeft <= 0 || adBusy) return;
    if (kind === 'rescue') { if (offerVisible()) hideOffer(); st.rescueOffers++; }
    else if (offerVisible() || st.time < st.offerGap) return;
    curOffer = { kind, n: n || 0 };
    st.offerGap = st.time + 45000;
    $('#offer-icon').textContent = OFFERS[kind].icon;
    $('#offer-text').textContent = I18n.t(OFFERS[kind].key);
    $('#offer').classList.remove('hidden');
    clearTimeout(offerT); offerT = setTimeout(hideOffer, 9000);
  }
  function rewardFor(o) {
    if (o.kind === 'rescue') return () => removeTop(3, false);
    if (o.kind === 'double') return () => {
      st.score += o.n; st.bar += o.n; floater(W / 2, H * .4, '×2  +' + o.n, '#ffd75e'); updateHud();
    };
    return () => { grantPerk(); st.bar += 150; updateHud(); };   // milestone
  }
  async function acceptOffer() {
    if (!curOffer) return;
    const o = curOffer; hideOffer();
    await runAd(o.kind, rewardFor(o));
  }

  // فرصة أخرى بعد الخسارة (مرة واحدة في كل مباراة): بإعلان أو بكوينز
  async function doContinue() {
    st.usedContinue = true; st.over = false; st.running = true;
    removeTop(4, true);
    allCoins().forEach(b => { b.over = 0; });
    $('#over-modal').classList.add('hidden');
    if (finishP) { await finishP; finishP = null; }
    if (lastSid) {
      const r = await Api.call('game/resume', 'POST', { session_id: lastSid });
      if (r.ok) sessionId = lastSid;
      lastSid = null;
    }
    updateHud();
  }
  async function continueGame() {
    if (!st.over || st.usedContinue) return;
    await runAd('continue', doContinue);
  }
  async function continueWithCoins() {
    if (!st.over || st.usedContinue || adBusy || buying) return;
    buying = true;
    if (finishP) await finishP;
    const r = await Api.call('shop/buy', 'POST', { item: 'continue' });
    buying = false;
    if (!r.ok) { toast((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : '')); refreshCoins(); return; }
    coins = r.coins; $('#coins').textContent = coins;
    await doContinue();
  }

  // ---------- الكوينز والمتجر (عملة داخل اللعبة فقط) ----------
  async function refreshCoins() {
    const r = await Api.call('coins/summary');
    if (!r.ok) return 0;
    const gain = r.coins - coins;
    coins = r.coins; if (r.prices) prices = r.prices;
    $('#coins').textContent = coins;
    if (st) updateHud();
    return gain;
  }
  // الضغط على مزية: تُستخدم إن كانت في المخزون، وإلا تُشترى بالكوينز ثم تُستخدم فوراً (السعر من الخادم)
  async function perkTap(k) {
    if (!st || !st.running || buying) return;
    if (st.perks[k] > 0) return usePerk(k);
    if (coins < (prices[k] || 0)) { toast(I18n.t('not_enough_coins')); return; }
    buying = true;
    const r = await Api.call('shop/buy', 'POST', { item: k });
    buying = false;
    if (!r.ok) { toast((r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : '')); refreshCoins(); return; }
    coins = r.coins; $('#coins').textContent = coins;
    st.perks[k] = 1; usePerk(k); updateHud();
  }

  // ---------- الواجهة ----------
  function updateHud() {
    if (!st) return;
    $('#score').textContent = st.score;
    $('#best').textContent = Math.max(best, st.score);
    $('#fill').style.width = Math.min(100, st.bar / st.target * 100) + '%';
    $('#bar-text').textContent = Math.min(st.bar, st.target) + '/' + st.target;
    $('#wheel-btn').disabled = st.bar < st.target;
    document.querySelectorAll('.perk').forEach(b => {
      const k = b.dataset.perk, n = st.perks[k], badge = b.querySelector('.badge');
      badge.textContent = n > 0 ? n : '🪙' + (prices[k] || '');
      badge.classList.toggle('price', n <= 0);
      b.disabled = false;
      b.classList.toggle('poor', n <= 0 && coins < (prices[k] || 0));
    });
  }

  function resize() {
    const stage = $('#stage'), aw = stage.clientWidth, ah = stage.clientHeight;
    const s = Math.min(aw / W, ah / H), d = window.devicePixelRatio || 1;
    const cw = Math.max(1, Math.floor(W * s)), ch = Math.max(1, Math.floor(H * s));
    board.style.width = cw + 'px'; board.style.height = ch + 'px';
    board.width = Math.floor(cw * d); board.height = Math.floor(ch * d);
  }

  // ---------- الرسم ----------
  function render(dt) {
    ctx.setTransform(board.width / W, 0, 0, board.height / H, 0, 0);
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#1a2a55'); bg.addColorStop(1, '#0f1a3a');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    // باب الخزنة (خلفية خافتة)
    ctx.strokeStyle = 'rgba(120,150,230,.10)'; ctx.lineWidth = 10;
    ctx.beginPath(); ctx.arc(W / 2, H * .58, 150, 0, Math.PI * 2); ctx.stroke();
    ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(W / 2, H * .58, 112, 0, Math.PI * 2); ctx.stroke();

    if (!st) return;
    // خط الخطر
    ctx.save();
    ctx.setLineDash([8, 6]); ctx.lineWidth = 2;
    ctx.strokeStyle = st.warn ? 'rgba(255,80,80,' + (.55 + .4 * Math.sin(st.time / 120)) + ')' : 'rgba(255,90,90,.35)';
    ctx.beginPath(); ctx.moveTo(0, DANGER_Y); ctx.lineTo(W, DANGER_Y); ctx.stroke();
    ctx.restore();

    // العملات
    for (const b of allCoins()) {
      if (b.pop > 0) b.pop = Math.max(0, b.pop - dt * 4);
      drawCoin(ctx, b.position.x, b.position.y, LEVELS[b.lv].r, b.lv, b.angle, 1 + b.pop * .25);
    }

    // مؤشر الإسقاط: مسار منقّط مائل حسب اتجاه الإطلاق
    if (st.running) {
      const L = LEVELS[st.cur], ready = st.time >= st.readyAt;
      if (ready) {
        const pts = predictPath();
        ctx.fillStyle = 'rgba(255,255,255,.6)';
        for (let i = 3; i < pts.length; i += 3) {
          const p = pts[i];
          if (Math.hypot(p.x - ORIGIN_X, p.y - DROP_Y) < L.r + 8) continue;
          ctx.beginPath(); ctx.arc(p.x, p.y, 2.4, 0, Math.PI * 2); ctx.fill();
        }
        const e = pts[pts.length - 1];
        if (e) {
          ctx.save(); ctx.setLineDash([4, 4]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.35)';
          ctx.beginPath(); ctx.arc(e.x, e.y, L.r, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
        }
      }
      ctx.globalAlpha = ready ? 1 : .35;
      drawCoin(ctx, ORIGIN_X, DROP_Y, L.r, st.cur, 0, 1);
      ctx.globalAlpha = 1;
    }

    // جزيئات ونصوص
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i]; p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 320 * dt;
      ctx.globalAlpha = clamp(p.life * 2, 0, 1); ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    for (let i = floaters.length - 1; i >= 0; i--) {
      const f = floaters[i]; f.life -= dt;
      if (f.life <= 0) { floaters.splice(i, 1); continue; }
      f.y -= 38 * dt;
      ctx.globalAlpha = clamp(f.life * 1.6, 0, 1);
      ctx.font = '800 18px system-ui, sans-serif';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.strokeText(f.text, clamp(f.x, 50, W - 50), f.y);
      ctx.fillStyle = f.color; ctx.fillText(f.text, clamp(f.x, 50, W - 50), f.y);
    }
    ctx.globalAlpha = 1;
    if (st.banner) {
      st.banner.t -= dt * .9;
      if (st.banner.t <= 0) st.banner = null;
      else {
        const s = 1 + (1 - st.banner.t) * .25;
        ctx.save(); ctx.translate(W / 2, H * .3); ctx.scale(s, s); ctx.globalAlpha = clamp(st.banner.t * 2, 0, 1);
        ctx.font = '900 54px "Arial Black", Impact, system-ui, sans-serif';
        ctx.lineWidth = 8; ctx.strokeStyle = '#0d5a12'; ctx.strokeText(I18n.t(st.banner.key), 0, 0);
        ctx.fillStyle = '#7dea3a'; ctx.fillText(I18n.t(st.banner.key), 0, 0); ctx.restore();
      }
    }
  }

  function frame(ts) {
    requestAnimationFrame(frame);
    const dtMs = Math.min(50, ts - (last || ts)); last = ts;
    if (st && st.running) {
      acc += dtMs;
      while (acc >= STEP) { Engine.update(engine, STEP); acc -= STEP; afterStep(); if (!st.running) break; }
    }
    render(dtMs / 1000);
  }

  // ---------- الإدخال ----------
  function aim(e) {
    const r = board.getBoundingClientRect();
    if (st) { st.aimX = (e.clientX - r.left) / r.width * W; st.aimY = (e.clientY - r.top) / r.height * H; }
  }
  board.addEventListener('pointerdown', e => { aim(e); board.setPointerCapture && board.setPointerCapture(e.pointerId); });
  board.addEventListener('pointermove', aim);
  board.addEventListener('pointerup', e => { aim(e); drop(); });

  document.querySelectorAll('.perk').forEach(b => b.addEventListener('click', () => perkTap(b.dataset.perk)));
  $('#wheel-btn').addEventListener('click', openWheel);
  $('#spin-btn').addEventListener('click', () => spin(false));
  $('#wheel-close').addEventListener('click', closeWheel);
  $('#again-btn').addEventListener('click', newGame);
  $('#ad-btn').addEventListener('click', watchAd);
  $('#offer-go').addEventListener('click', acceptOffer);
  $('#offer-x').addEventListener('click', hideOffer);
  $('#continue-btn').addEventListener('click', continueGame);
  $('#continue-coins-btn').addEventListener('click', continueWithCoins);
  $('#wheel-ad').addEventListener('click', () => runAd('extra_spin', () => spin(true)));
  document.querySelectorAll('[data-lang]').forEach(b => b.addEventListener('click', () => I18n.setLang(b.dataset.lang)));
  document.addEventListener('langchange', e => { Api.call('auth/lang', 'POST', { lang: e.detail }); });
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);

  I18n.apply(); resize(); drawWheelFace();
  newGame();
  updateAdBtn();
  refreshCoins();
  requestAnimationFrame(frame);
})();
