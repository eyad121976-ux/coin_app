(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  let sum = null;

  function paintDaily() {
    const b = $('#daily-btn');
    if (!sum) return;
    b.disabled = sum.daily_claimed;
    b.textContent = sum.daily_claimed ? I18n.t('claimed_today') : '🎁 ' + I18n.t('claim_daily') + ' (+' + sum.daily_bonus + ')';
  }

  async function refresh() {
    const s = await Ads.status();
    if (s.ok) $('#ad-count').textContent = s.today_verified + '/' + s.daily_limit;
    const c = await Api.call('coins/summary');
    if (c.ok) { sum = c; $('#balance').textContent = '🪙 ' + c.coins; paintDaily(); }
  }

  async function watch() {
    const b = $('#ad-btn'), m = $('#ad-msg');
    b.disabled = true; m.textContent = '';
    const r = await Ads.watch();
    b.disabled = false;
    m.textContent = r.ok ? I18n.t('ad_counted') : (r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : '');
    refresh();
  }

  async function claim() {
    const m = $('#ad-msg');
    const r = await Api.call('coins/claim_daily', 'POST', {});
    m.textContent = r.ok ? I18n.t('daily_ok').replace('{n}', r.bonus) : (r.message || I18n.t('network_error')) + (r.debug ? ' [' + r.debug + ']' : '');
    refresh();
  }

  document.addEventListener('homeshown', refresh);
  document.addEventListener('langchange', paintDaily);
  document.addEventListener('DOMContentLoaded', () => {
    $('#ad-btn').addEventListener('click', watch);
    $('#daily-btn').addEventListener('click', claim);
  });
})();
