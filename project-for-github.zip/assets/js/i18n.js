(function () {
  const dict = {
    ar: {
      app_name: 'دمج العملات',
      login: 'دخول', register: 'حساب جديد',
      username: 'اسم المستخدم', email: 'البريد الإلكتروني (اختياري)', password: 'كلمة المرور',
      submit_login: 'تسجيل الدخول', submit_register: 'إنشاء الحساب',
      welcome: 'أهلاً', balance: 'رصيدك من الكوينز', logout: 'تسجيل الخروج',
      phase_note: 'اجمع الكوينز من اللعب والإعلانات واستخدمها في المزايا داخل اللعبة.',
      network_error: 'تعذّر الاتصال بالخادم.', loading: 'جارٍ التحميل...',
      play: 'العب الآن',
      score: 'النقاط', best: 'الأفضل', next: 'التالية',
      wheel: 'العجلة', spin: 'أدِر العجلة', close: 'إغلاق',
      wheel_title: 'عجلة المزايا', wheel_won: 'ربحت: ',
      perk_bomb: 'قنبلة', perk_shake: 'رجّ', perk_big: 'عملة كبيرة', perk_rescue: 'إنقاذ',
      good: 'جيد!', great: 'رائع!', amazing: 'مذهل!', jackpot: 'جاكبوت!',
      game_over: 'انتهت اللعبة', new_record: 'رقم قياسي جديد!',
      play_again: 'العب مجدداً', back: 'رجوع',
      ad_today: 'إعلانات اليوم', ad_watch: 'شاهد إعلاناً', ad_watch_perk: 'شاهد إعلاناً = كوينز',
      ad_test: 'إعلان تجريبي', ad_test_note: 'هذا إعلان محاكاة لاختبار النظام ولا يولّد إيراداً.',
      ad_claim: 'استلم المكافأة', ad_cancelled: 'أُلغي الإعلان بدون مكافأة.',
      ad_pending: 'التحقق من الإعلان يتأخر، حاول بعد قليل.', ad_counted: 'تم اعتماد الإعلان وأُضيفت الكوينز إلى رصيدك.',
      ad_failed: 'تعذّر التحقق من الإعلان.',
      ad_go: 'شاهد', continue_ad: 'تابع اللعب (إعلان)', extra_spin_ad: 'دورة إضافية (إعلان)',
      offer_rescue: 'الحاوية تمتلئ! شاهد إعلاناً لإزالة العملات العليا.',
      offer_double: 'ضاعف نقاط هذا الدمج الكبير!',
      offer_milestone: 'إنجاز جديد! مزية مجانية + نقاط للعجلة.',
      history: 'سجل المعاملات', no_history: 'لا توجد معاملات بعد.', load_more: 'عرض المزيد',
      admin: 'لوحة الإدارة',
      st_rejected: 'مرفوض / ملغى',
      coins_page: 'الكوينز والمتجر', coins_note: 'الكوينز عملة داخل اللعبة فقط، ليس لها قيمة نقدية ولا يمكن تحويلها إلى مال أو هدايا.',
      game_today_note: 'كسبت اليوم من اللعب {a} من أصل {b}', earn_title: 'طرق الحصول على الكوينز',
      earn_ad: 'شاهد إعلاناً: +{n} كوينز (حتى الحد اليومي)', earn_play: 'العب: كل {d} نقطة = 1 كوينز (بسقف يومي)', earn_daily: 'المكافأة اليومية: +{n} كوينز',
      claim_daily: 'استلم المكافأة اليومية', claimed_today: 'استلمت مكافأة اليوم', daily_ok: 'تمت إضافة +{n} كوينز.',
      shop_title: 'المتجر (أسعار المزايا داخل اللعبة)', continue_item: 'المتابعة بعد الخسارة',
      ctx_game: 'مكافأة لعب', ctx_ad: 'مكافأة إعلان', ctx_daily: 'مكافأة يومية', ctx_purchase: 'شراء', ctx_adjustment: 'تسوية',
      not_enough_coins: 'لا تملك كوينز كافية.', continue_coins: 'تابع بـ {n} كوينز', over_coins: 'كوينز هذه المباراة'
    },
    en: {
      app_name: 'Coin Merge',
      login: 'Log in', register: 'New account',
      username: 'Username', email: 'Email (optional)', password: 'Password',
      submit_login: 'Log in', submit_register: 'Create account',
      welcome: 'Welcome', balance: 'Your coins', logout: 'Log out',
      phase_note: 'Collect coins from playing and ads, then use them for in-game perks.',
      network_error: 'Could not reach the server.', loading: 'Loading...',
      play: 'Play now',
      score: 'Score', best: 'Best', next: 'Next',
      wheel: 'Wheel', spin: 'Spin', close: 'Close',
      wheel_title: 'Perk wheel', wheel_won: 'You won: ',
      perk_bomb: 'Bomb', perk_shake: 'Shake', perk_big: 'Big coin', perk_rescue: 'Rescue',
      good: 'Good!', great: 'Great!', amazing: 'Amazing!', jackpot: 'Jackpot!',
      game_over: 'Game over', new_record: 'New record!',
      play_again: 'Play again', back: 'Back',
      ad_today: 'Ads today', ad_watch: 'Watch an ad', ad_watch_perk: 'Watch an ad = coins',
      ad_test: 'Test ad', ad_test_note: 'This is a simulated ad for testing. It earns no revenue.',
      ad_claim: 'Claim reward', ad_cancelled: 'Ad cancelled, no reward.',
      ad_pending: 'Ad verification is taking a while, try again shortly.', ad_counted: 'Ad verified and coins were added to your balance.',
      ad_failed: 'Could not verify the ad.',
      ad_go: 'Watch', continue_ad: 'Continue (ad)', extra_spin_ad: 'Extra spin (ad)',
      offer_rescue: 'Board is filling up! Watch an ad to clear the top coins.',
      offer_double: 'Double the points of this big merge!',
      offer_milestone: 'New milestone! Free perk + wheel points.',
      history: 'Transaction history', no_history: 'No transactions yet.', load_more: 'Load more',
      admin: 'Admin panel',
      st_rejected: 'Rejected / cancelled',
      coins_page: 'Coins & shop', coins_note: 'Coins are an in-game currency only. They have no cash value and cannot be exchanged for money or gift cards.',
      game_today_note: 'Earned from play today: {a} of {b}', earn_title: 'Ways to earn coins',
      earn_ad: 'Watch an ad: +{n} coins (up to the daily limit)', earn_play: 'Play: every {d} points = 1 coin (daily cap)', earn_daily: 'Daily bonus: +{n} coins',
      claim_daily: 'Claim daily bonus', claimed_today: 'Daily bonus claimed', daily_ok: '+{n} coins added.',
      shop_title: 'Shop (in-game perk prices)', continue_item: 'Continue after game over',
      ctx_game: 'Play reward', ctx_ad: 'Ad reward', ctx_daily: 'Daily bonus', ctx_purchase: 'Purchase', ctx_adjustment: 'Adjustment',
      not_enough_coins: 'Not enough coins.', continue_coins: 'Continue for {n} coins', over_coins: 'Coins this game'
    }
  };
  const BS = {
    ar: 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css',
    en: 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'
  };
  let lang = localStorage.getItem('lang');
  if (!dict[lang]) lang = 'ar';
  function t(key) { return (dict[lang] && dict[lang][key]) || dict.en[key] || key; }
  function apply() {
    const html = document.documentElement;
    html.lang = lang;
    html.dir = lang === 'ar' ? 'rtl' : 'ltr';
    const bs = document.getElementById('bs');
    if (bs && bs.getAttribute('href') !== BS[lang]) bs.setAttribute('href', BS[lang]);
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
    document.querySelectorAll('[data-lang]').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
    document.title = t('app_name');
  }
  function setLang(l) {
    if (!dict[l]) return;
    lang = l;
    localStorage.setItem('lang', l);
    apply();
    document.dispatchEvent(new CustomEvent('langchange', { detail: l }));
  }
  window.I18n = { t, apply, setLang, lang: () => lang };
})();
