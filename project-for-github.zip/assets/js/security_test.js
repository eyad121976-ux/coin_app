(function () {
  'use strict';
  const out = document.getElementById('sec-out');
  const counts = { PASS: 0, FAIL: 0, SKIP: 0, WARN: 0 };
  const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'd' + Date.now() + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  const uname = () => 'zt' + Math.random().toString(36).slice(2, 10);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function log(state, name, detail) {
    counts[state]++;
    const d = document.createElement('div'); d.className = 'row';
    d.innerHTML = '<b class="' + state + '">' + state + '</b> ' + name + (detail ? '<small>' + String(detail).replace(/</g, '&lt;') + '</small>' : '');
    out.appendChild(d);
  }
  const check = (name, cond, detail) => log(cond ? 'PASS' : 'FAIL', name, detail);

  async function api(route, method, body, token, raw) {
    const headers = { 'X-Lang': 'en' };
    if (token) headers['X-Auth-Token'] = token;
    const opt = { method: method || 'GET', headers };
    if (body !== undefined && body !== null) { headers['Content-Type'] = 'application/json'; opt.body = raw ? body : JSON.stringify(body); }
    try {
      const res = await fetch(APP_CONFIG.API_BASE + '?r=' + encodeURIComponent(route), opt);
      const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch (e) {}
      return { status: res.status, json, text, headers: res.headers };
    } catch (e) { return { status: 0, json: null, text: String(e), headers: new Headers() }; }
  }
  const rejected = r => r.status >= 400 && r.status < 500 && r.json && r.json.ok === false;
  const short = r => 'HTTP ' + r.status + ' ' + (r.json ? (r.json.error || '') + ' ' + (r.json.message || '') : r.text.slice(0, 80));

  async function register(name, device) {
    return api('auth/register', 'POST', { username: name, password: 'TestPass123!', device_id: device, lang: 'en' });
  }

  async function run() {
    out.innerHTML = ''; Object.keys(counts).forEach(k => counts[k] = 0);
    const ping = await api('system/ping');
    const devMode = ping.status === 200;
    log('SKIP', 'dev_mode: ' + (devMode ? 'ON (اختبارات الإعلانات ستعمل)' : 'OFF (تُتخطى اختبارات الإعلانات)'));

    // 1) مدخلات ضارة عند التسجيل
    for (const bad of ['ab', '<script>alert(1)</script>', "x' OR '1'='1", 'a'.repeat(21), 'مستخدم']) {
      const r = await api('auth/register', 'POST', { username: bad, password: 'TestPass123!', device_id: uid() });
      check('اسم مستخدم مرفوض: ' + bad.slice(0, 24), rejected(r), short(r));
    }
    for (const pw of ['short', 'p'.repeat(80)]) {
      const r = await api('auth/register', 'POST', { username: uname(), password: pw, device_id: uid() });
      check('كلمة مرور مرفوضة (طول ' + pw.length + ')', rejected(r), short(r));
    }
    const g = await api('auth/register', 'POST', 'garbage-not-json', null, true);
    check('جسم طلب غير صالح لا يسبب خطأ 500', g.status !== 500 && g.status !== 0, short(g));

    // 2) حساب صحيح + جهاز واحد لكل حساب
    const devA = uid(), nameA = uname();
    const a = await register(nameA, devA);
    check('تسجيل حساب صحيح', a.json && a.json.ok === true, short(a));
    if (!(a.json && a.json.ok)) { log('FAIL', 'توقف: لا يمكن متابعة الاختبارات بدون حساب', short(a)); return summary(); }
    const tokA = a.json.token;
    const dup = await register(uname(), devA);
    check('نفس الجهاز لا ينشئ حساباً ثانياً', dup.status === 409, short(dup));
    const hdr = a.headers.get('X-Content-Type-Options');
    check('ترويسة X-Content-Type-Options: nosniff موجودة', hdr === 'nosniff', 'value=' + hdr);

    // 3) المصادقة
    for (let i = 0; i < 3; i++) {
      const r = await api('auth/login', 'POST', { username: nameA, password: 'wrong-' + i + '-password', device_id: devA });
      check('دخول بكلمة مرور خاطئة #' + (i + 1), r.status === 401, short(r));
    }
    const sqli = await api('auth/login', 'POST', { username: "' OR 1=1 --", password: 'x', device_id: devA });
    check('حقن SQL في الدخول مرفوض', rejected(sqli), short(sqli));
    const method = await api('auth/login', 'GET');
    check('طريقة طلب خاطئة (GET على مسار POST)', method.status === 405, short(method));
    for (const [route, m] of [['auth/me', 'GET'], ['ads/request', 'POST'], ['coins/summary', 'GET'], ['shop/buy', 'POST'], ['game/start', 'POST']]) {
      const r = await api(route, m, m === 'POST' ? {} : undefined);
      check('بدون رمز دخول: ' + route, r.status === 401, short(r));
    }
    const forged = await api('auth/me', 'GET', undefined, 'a'.repeat(64));
    check('رمز دخول مزوَّر مرفوض', forged.status === 401, short(forged));
    const adm = await api('admin/overview', 'GET', undefined, tokA);
    check('مستخدم عادي لا يصل إلى لوحة الإدارة', adm.status === 403, short(adm));
    const adm2 = await api('admin/adjust', 'POST', { user_id: a.json.user.id, amount: '100', note: 'hack' }, tokA);
    check('مستخدم عادي لا يستطيع تعديل رصيده', adm2.status === 403, short(adm2));

    // 4) المتجر (كوينز داخل اللعبة فقط)
    const shop = [
      ['عنصر غير معروف', { item: 'unknown_item' }],
      ['عنصر فارغ', { item: '' }],
    ];
    for (const [name, body] of shop) {
      const r = await api('shop/buy', 'POST', body, tokA);
      check('شراء مرفوض: ' + name, rejected(r), short(r));
    }
    const poor = await api('shop/buy', 'POST', { item: 'bomb' }, tokA);
    check('شراء بدون رصيد كافٍ من الكوينز يُرفض', rejected(poor), short(poor));

    // 5) الألعاب
    const st = await api('game/start', 'POST', {}, tokA);
    if (st.json && st.json.ok) {
      const fin = await api('game/finish', 'POST', { session_id: st.json.session_id, score: 999999999, merges: 1, max_level: 8 }, tokA);
      check('نتيجة مستحيلة تُعلَّم غير صالحة', fin.json && fin.json.ok && fin.json.valid === false, short(fin) + ' valid=' + (fin.json && fin.json.valid));
      const fin2 = await api('game/finish', 'POST', { session_id: st.json.session_id, score: 1, merges: 1, max_level: 1 }, tokA);
      check('إغلاق نفس الجلسة مرتين مرفوض', rejected(fin2), short(fin2));
    } else log('FAIL', 'game/start', short(st));

    // 6) الإعلانات (dev فقط)
    if (!devMode) log('SKIP', 'اختبارات الإعلانات (تحتاج dev_mode)');
    else {
      const b = await register(uname(), uid()); const tokB = b.json && b.json.token;
      const r1 = await api('ads/request', 'POST', { placement: 'home' }, tokA);
      check('طلب إعلان', r1.json && r1.json.ok, short(r1));
      if (r1.json && r1.json.ok) {
        const early = await api('ads/dev_complete', 'POST', { nonce: r1.json.nonce }, tokA);
        check('اعتماد فوري (أقل من 4 ثوان) يُرفض', early.json && early.json.status === 'rejected', short(early) + ' status=' + (early.json && early.json.status));
        const r2 = await api('ads/request', 'POST', { placement: 'home' }, tokA);
        check('طلب إعلان بعد الرفض', r2.json && r2.json.ok, short(r2));
        const r3 = await api('ads/request', 'POST', {}, tokA);
        check('طلب ثانٍ فوراً يصطدم بالفاصل الزمني', r3.status === 429, short(r3));
        const badN = await api('ads/dev_complete', 'POST', { nonce: "1' OR '1'='1" }, tokA);
        check('nonce بصيغة خاطئة مرفوض', rejected(badN), short(badN));
        const fake = await api('ads/dev_complete', 'POST', { nonce: 'f'.repeat(32) }, tokA);
        check('nonce غير موجود لا يُعتمد', fake.json && fake.json.status === 'unknown', short(fake));
        if (r2.json && r2.json.ok && tokB) {
          const steal = await api('ads/dev_complete', 'POST', { nonce: r2.json.nonce }, tokB);
          check('مستخدم آخر لا يستطيع اعتماد إعلانك', steal.json && steal.json.status === 'unknown', short(steal));
          log('SKIP', 'انتظار 5 ثوانٍ لمحاكاة مشاهدة حقيقية...');
          await sleep(5200);
          const ok1 = await api('ads/dev_complete', 'POST', { nonce: r2.json.nonce }, tokA);
          check('اعتماد بعد مشاهدة كافية', ok1.json && ok1.json.status === 'verified', short(ok1));
          const ok2 = await api('ads/dev_complete', 'POST', { nonce: r2.json.nonce }, tokA);
          const stt = await api('ads/status', 'GET', undefined, tokA);
          check('إعادة اعتماد نفس الإعلان لا تُحتسب مرتين', ok2.json && ok2.json.status === 'verified' && stt.json && stt.json.today_verified === 1, 'today_verified=' + (stt.json && stt.json.today_verified));
        }
      }
    }
    summary();
  }

  function summary() {
    const d = document.createElement('div'); d.className = 'row';
    d.innerHTML = '<b>النتيجة:</b> <span class="PASS">PASS ' + counts.PASS + '</span> · <span class="FAIL">FAIL ' + counts.FAIL + '</span> · <span class="SKIP">SKIP ' + counts.SKIP + '</span>' +
      '<small>احذف حسابات الاختبار بتشغيل database/cleanup_security_test_users.sql ثم احذف security_test.html</small>';
    out.appendChild(d);
  }

  // اختبار القفل: 12 محاولة دخول خاطئة سريعة يجب أن تنتهي بـ 429
  async function lock() {
    out.innerHTML = '';
    let got429 = false;
    for (let i = 0; i < 12; i++) {
      const r = await api('auth/login', 'POST', { username: 'zt_nouser', password: 'bad-password-' + i, device_id: uid() });
      if (r.status === 429) { got429 = true; log('PASS', 'ظهر القفل بعد ' + (i + 1) + ' محاولة', short(r)); break; }
    }
    if (!got429) log('FAIL', 'لم يظهر القفل بعد 12 محاولة خاطئة');
    log('WARN', 'شبكتك الآن ممنوعة من الدخول لمدة 15 دقيقة (هذا هو المطلوب).');
  }

  document.getElementById('run').addEventListener('click', run);
  document.getElementById('lock').addEventListener('click', lock);
})();
