// يُشغَّل تلقائياً في GitHub Actions بعد npx cap add android.
// يضيف معرّف تطبيق AdMob إلى AndroidManifest.xml وstrings.xml (إن لم يكن موجوداً بالفعل - آمن للتكرار).
// معرّف حقيقي: ضعه كمتغيّر مستودع (Repository variable) باسم ADMOB_APP_ID في GitHub.
// بدون ذلك يُستخدم معرّف AdMob التجريبي الرسمي من جوجل (آمن للاختبار، لا تنشر به على المتجر).
const fs = require('fs');
const path = require('path');

const ADMOB_APP_ID = process.env.ADMOB_APP_ID || 'ca-app-pub-3940256099942544~3347511713';

const manifestPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const stringsPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res', 'values', 'strings.xml');

let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  manifest = manifest.replace(
    '</application>',
    '    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id"/>\n  </application>'
  );
  fs.writeFileSync(manifestPath, manifest);
  console.log('AndroidManifest.xml: تمت الإضافة');
} else {
  console.log('AndroidManifest.xml: موجود مسبقاً');
}

let strings = fs.readFileSync(stringsPath, 'utf8');
if (!strings.includes('name="admob_app_id"')) {
  strings = strings.replace('</resources>', '    <string name="admob_app_id">' + ADMOB_APP_ID + '</string>\n</resources>');
  fs.writeFileSync(stringsPath, strings);
  console.log('strings.xml: تمت الإضافة (' + ADMOB_APP_ID + ')');
} else {
  console.log('strings.xml: موجود مسبقاً');
}
