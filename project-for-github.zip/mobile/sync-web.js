// ينسخ ملفات الموقع الثابتة (بدون app/ و config/ و database/ و... الخادم) إلى mobile/www قبل كل npx cap sync.
// شغّله عبر: npm run sync:web  (أو npm run android الذي يشغّله تلقائياً)
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const out = path.join(__dirname, 'www');

const FILES = ['index.html', 'game.html', 'coins.html', 'admin.html'];
const DIRS = ['assets'];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

function copyDir(rel) {
  const src = path.join(root, rel), dst = path.join(out, rel);
  fs.mkdirSync(dst, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const s = path.join(src, entry.name), d = path.join(dst, entry.name);
    if (entry.isDirectory()) copyDir(path.join(rel, entry.name));
    else fs.copyFileSync(s, d);
  }
}

for (const f of FILES) fs.copyFileSync(path.join(root, f), path.join(out, f));
for (const d of DIRS) copyDir(d);

console.log('نُسخت ' + FILES.length + ' صفحة و' + DIRS.length + ' مجلد أصول إلى mobile/www');
